# PotterVilla E-commerce Website

## How to Run

### Backend:
1. Go to `server/`
2. Run `npm install`
3. Run `node server.js`

### Frontend:
1. Go to `client/`
2. Open `index.html` in browser (or use React setup for real app)
